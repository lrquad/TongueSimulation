#pragma once
#include "weightFunction/WeightFunction.h"
class WeightFunctionLaplacian :public WeightFunction
{
public:
	WeightFunctionLaplacian(LoboVolumetricMesh* volumetricMesh, std::vector<int> seed_index, SparseMatrix<double>* L);
	~WeightFunctionLaplacian();

	virtual void computeWeight();

protected:
	SparseMatrix<double>* Laplacianmatrix;
};


#include "DualQuaternionsFramebased.h"
#include "Render/LoboScene.h"

DualQuaternionsFramebased::DualQuaternionsFramebased()
{
	config_.youngs_modulus_ = 5000;
	config_.poisson_ratio_ = 0.3;
	config_.time_step_ = 1.0 / 100.0;
	config_.alpha_ = 0.01;
	config_.beta_ = 0.01;
	config_.density_RHI_ = 1;
	config_.beta_bar_ = 0.25;
	config_.gama_ = 0.5;
	config_.DOFs = 6;
	damp_ratio = 1;
}


DualQuaternionsFramebased::~DualQuaternionsFramebased()
{
	clear();
}

void DualQuaternionsFramebased::clear()
{

}

void DualQuaternionsFramebased::simulate()
{
	computeMatrix();
	computeExternalForce();
	simulateIntegrate();
	

	config_.simulator_life_time++;
}

void DualQuaternionsFramebased::simulateIntegrate()
{

	Damp_C_ = config_.alpha_*pre_data.Mass_M_ + config_.beta_*Stiffness_K_;

	system_A = pre_data.Mass_M_ - config_.time_step_ * Damp_C_ - config_.time_step_*config_.time_step_*Stiffness_K_;

	system_F = config_.time_step_*(E_force_+I_force_ + config_.time_step_*Stiffness_K_*qi_velocities_);

	lobo::subMatrix(system_A, system_A_prime, config_.map_sub_origin);
	lobo::subVector(system_F, system_F_prime, config_.map_sub_origin);

#ifdef EIGEN_USE_MKL_ALL
	VectorXd result_ = system_A_prime.selfadjointView<Upper>().ldlt().solve(system_F_prime);
#else
	Eigen::LDLT<MatrixXd> solver(system_A_prime);
	if (solver.info() != Success)
	{
		std::cout << "failed" << std::endl;
	}
	VectorXd result_ = solver.solve(system_F_prime);
#endif
	qi_step_result_.setZero();
	lobo::subVector(result_, qi_step_result_, config_.map_sub_origin);

	qi_velocities_ += qi_step_result_;
	qi_velocities_ *= damp_ratio;
}

void DualQuaternionsFramebased::computePureBending()
{
	for (int i = 0; i < sampleNodes_list_.size(); i++)
	{
		if (config_.constraint_mark[i])
		{
			continue;
		}

		int nodeid = i;
		Vector3d force;

		int neighborid = sampleNodes_list_[nodeid].neighbor[12];
		if (neighborid == -1)
		{
			continue;
		}

		Vector3d distance = sampleNodes_list_[nodeid].ele_displacement - sampleNodes_list_[neighborid].ele_displacement
			+ sampleNodes_list_[nodeid].ele_position - sampleNodes_list_[neighborid].ele_position;

		double distanceTonegZ = sampleNodes_list_[nodeid].ele_position.z();
		distanceTonegZ = 2 - std::abs(distanceTonegZ);

		Vector3d xaxis = Vector3d(1, 0, 0);
		Vector3d bendingdirection = xaxis.cross(distance);
		bendingdirection.normalize();

		bendingdirection *= twistforce_ratio*distanceTonegZ;
		
		MatrixXd jacobian;
		DualQuaternion b;
		DualQuaternion b_prime;
		frameQuaternionsBlending(sampleNodes_list_[nodeid], b, b_prime);
		for (int j = 0; j < frame_list_.size(); j++)
		{
			Jacobian_framei_point(jacobian, frame_list_[j], &sampleNodes_list_[nodeid].ele_position,&b_prime,&b,sampleNodes_list_[i].weights[j]);
			VectorXd force =  jacobian.transpose()*bendingdirection;

			for (int k = 0; k < config_.DOFs; k++)
			{
				E_force_.data()[j*config_.DOFs + k] += force.data()[k];
			}
		}
	}

	E_accelerate_.setZero();
}

void DualQuaternionsFramebased::computeExternalForce()
{
	E_force_.setZero();

	if (config_.b_gravity_mode == 5)
	{
		computePureBending();
	}

	if (config_.b_gravity_mode != 0)
	E_force_ += pre_data.Mass_M_*E_accelerate_;
}

void DualQuaternionsFramebased::updateTriMesh()
{
	for (int i = 0; i < frame_list_.size(); i++)
	{
		for (size_t j = 0; j < config_.DOFs; j++)
			frame_list_[i]->cur_position_.data()[j] = qi_velocities_.data()[i * config_.DOFs + j];
		frame_list_[i]->updateMatrix(config_.time_step_);
	}

	for (int i = 0; i < sampleNodes_list_.size(); i++)
	{
		if (config_.constraint_mark[i])
		{
			continue;
		}

		DualQuaternion b;
		b.nondual.setZero();
		b.dual.setZero();
		for (int j = 0; j<this->frame_list_.size(); j++)
		{
			double w = sampleNodes_list_[i].weights[j];
			b = b + w*(frame_list_[j]->ori_position->productMatrixT()*(*frame_list_[j]->cur_position));
		}
		b.normlized();
		Vector3d temp = b.getTransforRotationMatirx()*(sampleNodes_list_[i].ele_position);
		sampleNodes_list_[i].ele_displacement = temp + b.getTransforTranslation() - sampleNodes_list_[i].ele_position;
	}

	int rows = mesh_->positions->size() / 3;
	int cols = frame_list_.size();
	VectorXd tri_dis_(mesh_->positions->size());
	tri_dis_.setZero();
	for (int i = 0; i < mesh_->positions->size() / 3; i++)
	{
		DualQuaternion b;
		b.nondual.setZero();
		b.dual.setZero();
		for (int j = 0; j<this->frame_list_.size(); j++)
		{
			double w = tri_weight.data()[j*rows+i];
			b = b + w*(frame_list_[j]->ori_position->productMatrixT()*(*frame_list_[j]->cur_position));
		}
		b.normlized();
		Vector3d p_bar = Vector3d(mesh_position.data()[i * 3], mesh_position.data()[i * 3 + 1], mesh_position.data()[i * 3 + 2]);
		Vector3d temp = b.getTransforRotationMatirx()*(p_bar);
		Vector3d displacement = temp + b.getTransforTranslation() - p_bar;
		tri_dis_.data()[i * 3 + 0] = displacement.data()[0];
		tri_dis_.data()[i * 3 + 1] = displacement.data()[1];
		tri_dis_.data()[i * 3 + 2] = displacement.data()[2];
	}

	for (int i = 0; i < mesh_->displacement.size(); i++)
	{
		mesh_->displacement[i] = tri_dis_.data()[i];
	}
	mesh_render_->updateDisplacement(mesh_->displacement.data());


	if (save_trajectory)
	{
		saveTrajectory(sampleNodes_list_[trajectory_nodeid].ele_displacement, trajectory_, "FRAME_BASED");
	}
}

void DualQuaternionsFramebased::resetSimulator()
{

}

void DualQuaternionsFramebased::drawSimulator(QOpenGLShaderProgram *program)
{
	int DiffuseProduct_loc = program->uniformLocation("DiffuseProduct");
	int BoolPoint_loc = program->uniformLocation("point");

	//draw elements
	program->setUniformValue(BoolPoint_loc, 1);
	program->setUniformValue(DiffuseProduct_loc, QVector4D(0, 0.5, 1.0, 1));
	glPointSize(10);

	//if (0)

	if (config_.b_draw_element)
	{
		//select which region will show. if display_region = 0 display all.
		display_region = display_region % (frame_list_.size() + 1);
		if (b_draw_weight)
			for (int i = 0; i < sampleNodes_list_.size(); i++)
			{
				int regioncolor = sampleNodes_list_[i].region_;
				if (display_region != 0)
				{
					regioncolor = (display_region - 1);
					if (frame_list_[regioncolor]->node_list_mark.size()>0)
						if (!frame_list_[regioncolor]->node_list_mark[i])
						{
							continue;
						}
				}

				double wi = std::abs(sampleNodes_list_[i].weights[regioncolor]) / 1.0;
				regioncolor %= ((sizeof(lobo::colortable) / sizeof(float)) / 3);
				QVector4D color = QVector4D(lobo::colortable[regioncolor * 3] * wi, lobo::colortable[regioncolor * 3 + 1] * wi, lobo::colortable[regioncolor * 3 + 2] * wi, 1);

				if (display_region != 0)
				{
					regioncolor = (display_region - 1);
					if (frame_list_[regioncolor]->node_list_mark.size()>0)
						if (frame_list_[regioncolor]->node_list_mark[i] == 2)
						{
							color = QVector4D(1, 0, 0, 1);
						}
				}

				if (sampleNodes_list_[i].config_.is_selected)
				{
					glPointSize(20);
					color = QVector4D(1, 0, 0, 1);
				}
				else
				{
					glPointSize(10);
				}

				if ((i == 3094 || i == 1295))
				{
					color = QVector4D(1, 0, 0, 1);
				}

				program->setUniformValue(DiffuseProduct_loc, color);
				glNormal3f(0, 0, 1);
				glBegin(GL_POINTS);
				glVertex3f(sampleNodes_list_[i].ele_position.x() + sampleNodes_list_[i].ele_displacement.x(),
					sampleNodes_list_[i].ele_position.y() + sampleNodes_list_[i].ele_displacement.y(),
					sampleNodes_list_[i].ele_position.z() + sampleNodes_list_[i].ele_displacement.z());
				glEnd();
			}

		//draw key elements
		if (!b_draw_weight)
			if (keyelements_indcies.size() > 0)
			{
				int region;
				glPointSize(10);
				QVector4D color = QVector4D(0, 0, 1, 1);
				program->setUniformValue(DiffuseProduct_loc, color);

				for (int k = 0; k < keyelements_indcies.size(); k++)
				{
					int i = keyelements_indcies[k];

					if (display_region != 0)
					{
						region = (display_region - 1);
						if (frame_list_[region]->node_list_mark.size()>0)
							if (!frame_list_[region]->node_list_mark[i])
							{
								continue;
							}
					}

					glNormal3f(0, 0, 1);
					glBegin(GL_POINTS);
					glVertex3f(sampleNodes_list_[i].ele_position.x() + sampleNodes_list_[i].ele_displacement.x(),
						sampleNodes_list_[i].ele_position.y() + sampleNodes_list_[i].ele_displacement.y(),
						sampleNodes_list_[i].ele_position.z() + sampleNodes_list_[i].ele_displacement.z());
					glEnd();
				}
			}

		glPointSize(30);

		//draw frame seed.

		for (int f = 0; f < frame_list_.size(); f++)
		{
			if (display_region != 0)
			{
				if (f != display_region - 1)
					continue;
			}

			int i = frame_list_[f]->ele_index_;
			QVector4D color = QVector4D(1, 0, 0, 1);
			program->setUniformValue(DiffuseProduct_loc, color);
			glNormal3f(0, 0, 1);
			glBegin(GL_POINTS);
			glVertex3f(sampleNodes_list_[i].ele_position.x() + sampleNodes_list_[i].ele_displacement.x(),
				sampleNodes_list_[i].ele_position.y() + sampleNodes_list_[i].ele_displacement.y(),
				sampleNodes_list_[i].ele_position.z() + sampleNodes_list_[i].ele_displacement.z());
			glEnd();
		}
	}
	program->setUniformValue(BoolPoint_loc, 0);

	if (config_.b_draw_constraint)
		this->drawRect(program, pre_data.select_rect);
}

void DualQuaternionsFramebased::paintSimulator(QPainter &painter)
{

}

void DualQuaternionsFramebased::keyPressEvent(QKeyEvent *key_event)
{

}

void DualQuaternionsFramebased::keyReleaseEvent(QKeyEvent *key_event)
{

}

void DualQuaternionsFramebased::init()
{
	std::cout << "init dual quaternions simulator ... ";
	config_.mu_ = config_.youngs_modulus_ / 2.0 / (1.0 + config_.poisson_ratio_);
	config_.lambda_ = config_.youngs_modulus_*config_.poisson_ratio_ / (1.0 + config_.poisson_ratio_) / (1.0 - 2.0 * config_.poisson_ratio_);
	config_.full_DOFs = frame_list_.size()*config_.DOFs;
	config_.alpha_newmark[0] = 1.0 / (config_.beta_bar_*config_.time_step_*config_.time_step_);
	config_.alpha_newmark[1] = 1.0 / (config_.beta_bar_*config_.time_step_);
	config_.alpha_newmark[2] = (1.0 - 2.0 * config_.beta_bar_) / (2.0 * config_.beta_bar_);
	config_.alpha_newmark[3] = config_.gama_ / (config_.beta_bar_*config_.time_step_);
	config_.alpha_newmark[4] = 1.0 - config_.gama_ / config_.beta_bar_;
	config_.alpha_newmark[5] = (1.0 - config_.gama_ / (2.0 * config_.beta_bar_))*config_.time_step_;
	int fullsize = frame_list_.size()*config_.DOFs;
	Stiffness_K_.resize(fullsize, fullsize);
	I_force_.resize(fullsize);
	E_force_.resize(fullsize);
	E_accelerate_.resize(fullsize);
	qi_step_result_.resize(fullsize);
	qi_positions_.resize(fullsize);
	qi_next_positions_.resize(fullsize);
	qi_velocities_.resize(fullsize);
	qi_accelerations_.resize(fullsize);

	dP_dF9.resize(9, 9);
	m_12x9_dfdF.resize(config_.DOFs, 9);

	E_accelerate_.setZero();
	full_accelerate_.resize(sampleNodes_list_.size() * 3);
	full_accelerate_.setZero();

	int cols = displacement_save_.cols();
	displacement_save_.resize(sampleNodes_list_.size() * 3, cols);
	displacement_save_.setZero();

	for (size_t i = 0; i < frame_list_.size(); i++)
	{
		E_accelerate_.data()[i * config_.DOFs + 4] = -9.8;
	}

	pre_data.Mass_M_.resize(fullsize, fullsize);

	if (!config_.b_loadpredata)
	{
		pre_data.wX_.resize(sampleNodes_list_.size() * 3, fullsize);
		pre_data.wX_trimesh_.resize(mesh_->positions->size(), fullsize);
		pre_data.trinode_map_.resize(mesh_->positions->size(), 1);
	}

	if (config_.b_save_pose || config_.b_training || config_.b_use_cubature)
		initCubatureData();

	if (config_.b_sparse_invertible)
		initKeyElements();
	
	std::cout << "end" << std::endl;
}

void DualQuaternionsFramebased::preCompute()
{
	std::cout << "init precompute ... ";
	Stiffness_K_.setZero();
	pre_data.Mass_M_.setZero();
	qi_velocities_.setZero();
	qi_accelerations_.setZero();
	qi_positions_.setZero();
	qi_next_positions_.setZero();
	E_force_.setZero();

	initConstraintMap();

	preComputeElement(sampleNodes_list_);

	//E_accelerate_ = this->pre_data.wX_.jacobiSvd(ComputeThinU | ComputeThinV).solve(full_accelerate_);
	if (!config_.b_loadpredata)
	{
		preComputeTriMeshwX();
		pre_data.save();
	}

	if (config_.b_training)
	{
		trainingCubatureData();
	}

	std::cout << "end" << std::endl;

}

void DualQuaternionsFramebased::preComputeTriMeshwX()
{
	int rows = mesh_->positions->size() / 3;
	int cols = frame_list_.size();
	tri_weight.resize(rows, cols);
	tri_weight.setZero();
	
	mesh_position.resize(rows * 3);
	for (int i = 0; i < mesh_->positions->size(); i++)
	{
		mesh_position.data()[i] = mesh_->positions->data()[i];
	}

	for (int i = 0; i < mesh_->positions->size() / 3; i++)
	{

		Vector3d p_bar = Vector3d(mesh_->positions->data()[i * 3], mesh_->positions->data()[i * 3 + 1], mesh_->positions->data()[i * 3 + 2]);

		int elementid = lobo::searchClosedSamplePoint(sampleNodes_list_, p_bar);
		this->pre_data.trinode_map_.data()[i] = elementid;
		for (int j = 0; j < frame_list_.size(); j++)
		{
			double wi = computeTriWeightByElement(p_bar, elementid, j);
			tri_weight.data()[j*rows + i] = wi;
		}
	}
}

void DualQuaternionsFramebased::computeJacobiX(MatrixXd &X, Vector3d& p_bar)
{

}

void DualQuaternionsFramebased::preComputeElement(std::vector<QuadraticElement>& elementlist)
{
	//this method's Mass is not constant
	for (int i = 0; i < elementlist.size(); i++)
	{
		elementlist[i].youngs_modulus_ = config_.youngs_modulus_;

		elementlist[i].poisson_ratio_ = config_.poisson_ratio_;
		elementlist[i].mu_ = config_.mu_;
		elementlist[i].lambda_ = config_.lambda_;
		elementlist[i].density_RHI_ = config_.density_RHI_;
		elementlist[i].jacobi.resize(frame_list_.size());
	}
}

void DualQuaternionsFramebased::computeWeight(int type, int readmode)
{
	//init weight
	for (int i = 0; i < sampleNodes_list_.size(); i++)
	{
		sampleNodes_list_[i].weights.clear();
		sampleNodes_list_[i].weight_gradients.clear();
		sampleNodes_list_[i].weights.resize(frame_list_.size());
		sampleNodes_list_[i].weight_gradients.resize(frame_list_.size());
	}

	InvertibleQuadraticFrameSimulator::computeWeight(type, readmode);

}

void DualQuaternionsFramebased::readConfig(std::ifstream &inStream, LoboScene* scene)
{
	std::string token;
	while (true)
	{
		inStream >> token;
		if (token == "end")
		{
			std::cout << "simulator created" << std::endl;
			std::cout << std::endl;
			break;
		}

		if (token[0] == '#')
		{
			inStream.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		}

		if (token == "damp_ratio")
		{
			inStream >> damp_ratio;
		}

		if (token == "bindmesh")
		{
			std::cout << "bind mesh ";
			int number;
			inStream >> number;
			std::cout << number << std::endl;
			assert(number < scene->model_list_.size() && number >= 0);
			bind(scene->model_list_[number]);
			bindRender(scene->model_list_[number]);
		}

		if (token == "savetrajectory")
		{
			int nodeid;
			int rows;
			inStream >> nodeid >> rows;
			trajectory_nodeid = nodeid;
			trajectory_.resize(rows, 2);
			trajectory_.setZero();
			displacement_save_.resize(1, rows);
			angles_save_.resize(rows);
			angles_save_.setZero();
			save_trajectory = true;
		}

		if (token == "twistforce")
		{
			inStream >> twistforce_ratio;
		}

		if (token == "load")
		{
			std::cout << "load element mesh :";
			std::string filebase;
			inStream >> filebase;
			std::cout << filebase << std::endl;
			//parent function will init a quadratic element list. For computing weight here.
			loadElementBase(filebase.c_str());
			//init multi weight element
		}

		if (token == "alpha_")
		{
			inStream >> config_.alpha_;
		}

		if (token == "beta_")
		{
			inStream >> config_.beta_;
		}

		if (token == "frame")
		{
			std::cout << "load frames :";
			std::string filebase;
			inStream >> filebase;
			std::cout << filebase << std::endl;
			loadFrameBase(filebase.c_str());
			InvertibleQuadraticFrameSimulator::loadFrameBase(filebase.c_str());
		}

		if (token == "computeweight")
		{
			std::cout << "compute weight: ";
			int type, readmode;
			inStream >> type >> readmode;
			weight_type = type;

			//use parent's method to compute weight
			computeWeight(type, readmode);
			std::cout << "finshed." << std::endl;
		}

		if (token == "constrainframe")
		{
			int frame_id;
			inStream >> frame_id;
			setFrameConstrain(frame_id);
		}

		if (token == "gravity")
		{
			int on;
			inStream >> on;
			config_.b_gravity_mode = on;
		}

		if (token == "predata")
		{
			std::cout << "predata :";
			int mode;
			inStream >> mode;
			std::string filebase;
			inStream >> filebase;
			std::cout << filebase << std::endl;
			loadPreComputeData(filebase.c_str(), mode);
		}

		if (token == "youngs_modulus_")
		{
			inStream >> config_.youngs_modulus_;
		}

		if (token == "poisson_ratio_")
		{
			inStream >> config_.poisson_ratio_;
		}

		if (token == "density_RHI_")
		{
			inStream >> config_.density_RHI_;
		}

		if (token == "b_draw_weight")
		{
			inStream >> b_draw_weight;
		}

		if (token == "ratioofkeyelement_weight")
		{
			inStream >> ratioofkeyelement_weight;
		}

		if (token == "ratioofkeyelement_weightgradient")
		{
			inStream >> ratioofkeyelement_weightgradient;
		}

		if (token == "save_pose_training_data")
		{
			config_.b_save_pose = true;
			int numberofpose;
			inStream >> numberofpose;
			config_.cubature_trainingsize = numberofpose;
		}

		if (token == "read_training_save_data")
		{
			config_.b_training = true;
			std::string cubature_base;
			inStream >> cubature_base;
			pre_data.cubaturefilenamebase = cubature_base;
		}

		if (token == "TOL")
		{
			double tol;
			inStream >> tol;
			config_.cubature_TOL = tol;
		}

		if (token == "use_cubature")
		{
			config_.b_use_cubature = true;
			std::string cubature_base;
			inStream >> cubature_base;
			pre_data.cubaturefilenamebase = cubature_base;
			pre_data.readCubature();
			std::cout << "read " << pre_data.cubature_result.size() << " cubatrue points." << std::endl;
		}

		if (token == "tet")
		{
			inStream >> pre_data.tetdatafilenamebase;
		}

		if (token == "select_rect")
		{
			inStream >> pre_data.select_rect.x1;
			inStream >> pre_data.select_rect.x2;
			inStream >> pre_data.select_rect.y1;
			inStream >> pre_data.select_rect.y2;
			inStream >> pre_data.select_rect.z1;
			inStream >> pre_data.select_rect.z2;
			pre_data.select_rect.x1 += mesh_->modeltranslate.x();
			pre_data.select_rect.x2 += mesh_->modeltranslate.x();
			pre_data.select_rect.y1 += mesh_->modeltranslate.y();
			pre_data.select_rect.y2 += mesh_->modeltranslate.y();
			pre_data.select_rect.z1 += mesh_->modeltranslate.z();
			pre_data.select_rect.z2 += mesh_->modeltranslate.z();
		}

		if (token == "b_draw_constraint")
		{
			inStream >> config_.b_draw_constraint;
		}

		if (token == "b_draw_element")
		{
			inStream >> config_.b_draw_element;
		}

		if (token == "b_local_frame")
		{
			inStream >> config_.b_local_frame;
		}

		if (token == "b_sparse_invertible")
		{
			inStream >> config_.b_sparse_invertible;
		}

		if (token == "b_cubature_invertible")
		{
			inStream >> config_.b_cubature_invertible;
		}

		if (token == "b_our_principal")
		{
			inStream >> b_our_principal;
		}

		if (token == "search_ratio")
		{
			inStream >> search_ratio;
		}

		if (token == "b_draw_modes")
		{
			inStream >> b_draw_modes;
		}
	}
}

void DualQuaternionsFramebased::loadFrameBase(const char* filebase)
{
	std::ostringstream frame;
	frame << filebase << ".txt";
	std::string framefilename = frame.str();
	int numberofframe;
	std::ifstream instream;
	instream.open(framefilename);
	instream >> numberofframe;
	frame_list_.resize(numberofframe);               

	for (int i = 0; i < numberofframe; i++)
	{
		frame_list_[i] = new DualQuaternionFrame();
		int index;
		double x, y, z;
		instream >> index >> x >> y >> z;
		frame_list_[i]->position_.ori_position = Vector3d(x, y, z) + mesh_->translate;
		Matrix3d rotation = Matrix3d::Identity();
		frame_list_[i]->ori_position->setPosition(frame_list_[i]->position_.ori_position, rotation);
		frame_list_[i]->cur_position->setPosition(frame_list_[i]->position_.ori_position, rotation);
		frame_list_[i]->translation_ = frame_list_[i]->position_.ori_position;

		frame_list_[i]->index_ = i;
		frame_list_[i]->ele_index_ = lobo::searchClosedSamplePoint(sampleNodes_list_, frame_list_[i]->position_.ori_position);
	}

	instream.close();
}

void DualQuaternionsFramebased::computeMatrix()
{
	I_force_.setZero();
	Stiffness_K_.setZero();
	pre_data.Mass_M_.setZero();
	this->computeMatrixByElement(sampleNodes_list_);
}

void DualQuaternionsFramebased::computeMatrixByElement(std::vector<QuadraticElement>& elementlist, VectorXd *internalforce, std::vector<int> *regionnode_indices, std::vector<double> *cubature_weight, bool fillstiffnes, bool invertible, MatrixXd *stiffness)
{
	if (internalforce == NULL)
	{
		internalforce = &I_force_;
	}

	if (stiffness == NULL)
	{
		stiffness = &Stiffness_K_;
	}

	if (regionnode_indices == NULL)
	{
		regionnode_indices = new std::vector < int >;
		regionnode_indices->resize(elementlist.size());
		for (int i = 0; i < elementlist.size(); i++)
		{
			regionnode_indices->at(i) = i;
		}
	}

	DualQuaternion b;
	DualQuaternion b_prime;
	for (int t = 0; t < regionnode_indices->size(); t++)
	{
		int s = regionnode_indices->at(t);

		if (config_.constraint_mark[s])
		{
			continue;
		}

		this->computeHooke_Stiffness_Matrix(Hooke_Stiffness_Matrix, elementlist[s].youngs_modulus_, elementlist[s].poisson_ratio_);

		frameQuaternionsBlending(elementlist[s], b, b_prime);
		
		R_s = b_prime.getTransforRotationMatirx(); // 3*3
		t_s = b_prime.getTransforTranslation();
		
		partialP_BPrime_Q(Q_s, &elementlist[s].ele_position, &b_prime);
		partial_Opertor_BPrime_Ns(N_s, &b, &b_prime);
		Partial_Opertor_b_pbar_W(W_s, elementlist[s]);
		computeDeformationGradientF(F_s,R_s, Q_s, N_s, W_s);
		strain_tensor_E(F_s,E_s);
	
		for (int i = 0; i < frame_list_.size(); i++)
		{
			double wi;
			wi = elementlist[s].weights[i];
			Ti = frame_list_[i]->ori_position->productMatrixT();
			Partial_Opertor_L_i(L_i, frame_list_[i]);
			Jacobian_framei_point(J_si,wi, Q_s, N_s, Ti, L_i);
			Partial_B_i(B_si, wi, &elementlist[s], &b, &b_prime, frame_list_[i], Q_s, N_s, Ti, W_s, L_i, F_s, i);

			pre_data.Mass_M_.block(i * config_.DOFs, i * config_.DOFs, config_.DOFs, config_.DOFs) += elementlist[s].density_RHI_ * J_si.transpose()*J_si*elementlist[s].volume_;
			
			internalforce->block(i * config_.DOFs, 0, config_.DOFs, 1) -= B_si.transpose()*Hooke_Stiffness_Matrix*E_s*elementlist[s].volume_;

			for (int j = 0; j <= i; j++)
			{
				MatrixXd B_sj = frame_list_[j]->B_i;
				stiffness->block(i * config_.DOFs, j * config_.DOFs, config_.DOFs, config_.DOFs) -= B_si.transpose()*Hooke_Stiffness_Matrix*B_sj
					*elementlist[s].volume_;
			}
		}
	}

	if (fillstiffnes)
		for (int i = 0; i<frame_list_.size(); i++)
		{
			for (int j = 0; j<i; j++)
			{
				stiffness->block(j * config_.DOFs, i * config_.DOFs, config_.DOFs, config_.DOFs)
					= stiffness->block(i * config_.DOFs, j * config_.DOFs, config_.DOFs, config_.DOFs).transpose();
			}
		}

}

void DualQuaternionsFramebased::Partial_B_i(MatrixXd &B_i, double wi,
	QuadraticElement* element,
	DualQuaternion* b,
	DualQuaternion* b_prime,
	DualQuaternionFrame* frame_i,
	MatrixXd &Q,
	MatrixXd &N,
	MatrixXd &Ti,
	MatrixXd &W,
	MatrixXd &Li,
	MatrixXd &Fi,
	int frame_number)
{
	B_i.resize(6, 6);
	B_i.setZero();

	std::vector<MatrixXd> F_i;
	std::vector<MatrixXd> E;
	MatrixXd NTL = N*Ti*Li; //8*6
	MatrixXd TL = Ti*Li;//8*6
	VectorXd R_V8(8, 1);
	VectorXd W_i_V8(8, 1);
	VectorXd Q_i_V8(8, 1);
	VectorXd N_i_V8(8, 1);

	F_i.resize(6);
	E.resize(6);

	for (int i = 0; i<6; i++)
	{
		getColumnVectorFromMatrix(NTL, i, R_V8);
		getColumnVectorFromMatrix(Li, i, W_i_V8);
		getColumnVectorFromMatrix(NTL, i, Q_i_V8);
		getColumnVectorFromMatrix(TL, i, N_i_V8);
		F_i[i].resize(3, 3);
		Partial_DOFS_F_k(F_i[i], wi, element, b, b_prime, frame_i,
			R_V8, W_i_V8, Q_i_V8, N_i_V8, Q, N, Ti, W, frame_number);
	}

	for (int i = 0; i<6; i++)
	{
		E[i].resize(3, 3);
		E[i] = Fi.transpose()*F_i[i];
	}
	for (int i = 0; i<6; i++)
	{
		E[i] += F_i[i].transpose()*Fi;
		E[i] *= 0.5;
	}

	VectorXd V6;
	V6.resize(6);
	for (int i = 0; i<6; i++)
	{
		//E[i]*=0.5;
		transforMatrixToVector(E[i], V6);
		setColumnVectorFromMatrix(V6, i, B_i);
	}

	frame_i->B_i = B_i;
}

void DualQuaternionsFramebased::Partial_DOFS_F_k(
	MatrixXd &output,
	double wi,
	QuadraticElement* element,
	DualQuaternion* b,
	DualQuaternion* b_prime,
	DualQuaternionFrame* frame_i,
	VectorXd& R_V8,
	VectorXd &W_i_V8,
	VectorXd &Q_i_V8,
	VectorXd &N_i_V8,
	MatrixXd &Q,
	MatrixXd &N,
	MatrixXd &Ti,
	MatrixXd &W,
	int frame_number
	)
{
	Vector3d p_bar = element->ele_position;
	MatrixXd w_i = element->weight_gradients[frame_number];

	MatrixXd delta_R;
	MatrixXd delta_W;
	MatrixXd delta_Q;
	MatrixXd delta_N;

	Partial_Opertor_R_b(delta_R, R_V8, b_prime);
	Partial_Opertor_W_q(delta_W,W_i_V8, w_i);
	Partial_Opertor_Q_b(delta_Q,Q_i_V8, &p_bar);
	Partial_OPertor_N_b(delta_N,N_i_V8, b, b_prime);

	output = (wi*delta_R)
		+ (Q*N*Ti*delta_W)
		+ (wi*delta_Q*N*W)
		+ (wi*Q*delta_N*W);
}

void DualQuaternionsFramebased::Partial_Opertor_W_q(MatrixXd &w_q, VectorXd &V8, MatrixXd &W_i)
{
	w_q.resize(8, 3);
	w_q = V8*W_i;
}

void DualQuaternionsFramebased::Partial_Opertor_R_b(MatrixXd &R_b, VectorXd &v, DualQuaternion* b_prime)
{
	R_b.resize(3, 3);
	double a0, b0, c0, w0;
	a0 = b_prime->nondual(0);
	b0 = b_prime->nondual(1);
	c0 = b_prime->nondual(2);
	w0 = b_prime->nondual(3);

	R_b(0, 0) = -2.0*(b0*v(1) + c0*v(2));
	R_b(0, 1) = -c0*v(3) + b0*v(0) + a0*v(1) - w0*v(2);
	R_b(0, 2) = b0*v(3) + c0*v(0) + w0*v(1) + a0*v(2);
	R_b(1, 0) = c0*v(3) + b0*v(0) + a0*v(1) + w0*v(2);
	R_b(1, 1) = -2.0*(a0*v(0) + c0*v(2));
	R_b(1, 2) = -a0*v(3) - w0*v(0) + c0*v(1) + b0*v(2);
	R_b(2, 0) = -b0*v(3) + c0*v(0) - w0*v(1) + a0*v(2);
	R_b(2, 1) = a0*v(3) + w0*v(0) + c0*v(1) + b0*v(2);
	R_b(2, 2) = -2.0*(a0*v(0) + b0*v(1));

	R_b *= 2;
}

void DualQuaternionsFramebased::Partial_Opertor_Q_b(MatrixXd &Qb, VectorXd &v, Vector3d* p_bar) //input 8*1 vector; output 3*8;
{
	Qb.resize(3, 8);
	Qb.setZero();
	double x, y, z;
	x = p_bar->x();
	y = p_bar->y();
	z = p_bar->z();
	Qb(0, 0) = x*v(0) + y*v(1) + z*v(2) - v(7);
	Qb(0, 1) = z*v(3) + y*v(0) - x*v(1) + v(6);
	Qb(0, 2) = -y*v(3) + z*v(0) - x*v(2) - v(5);
	Qb(0, 3) = x*v(3) + z*v(1) - y*v(2) + v(4);
	Qb(0, 4) = v(3);
	Qb(0, 5) = -v(2);
	Qb(0, 6) = v(1);
	Qb(0, 7) = -v(0);

	Qb(1, 0) = -z*v(3) - y*v(0) + x*v(1) - v(6);
	Qb(1, 1) = x*v(0) + y*v(1) + z*v(2) - v(7);
	Qb(1, 2) = x*v(3) + z*v(1) - y*v(2) + v(4);
	Qb(1, 3) = y*v(3) - z*v(0) + x*v(2) + v(5);
	Qb(1, 4) = v(2);
	Qb(1, 5) = v(3);
	Qb(1, 6) = -v(0);
	Qb(1, 7) = -v(1);

	Qb(2, 0) = y*v(3) - z*v(0) + x*v(2) + v(5);
	Qb(2, 1) = -x*v(3) - z*v(1) + y*v(2) - v(4);
	Qb(2, 2) = x*v(0) + y*v(1) + z*v(2) - v(7);
	Qb(2, 3) = z*v(3) + y*v(0) - x*v(1) + v(6);
	Qb(2, 4) = -v(1);
	Qb(2, 5) = v(0);
	Qb(2, 6) = v(3);
	Qb(2, 7) = -v(2);

	Qb *= 2;
}

void DualQuaternionsFramebased::Partial_OPertor_N_b(MatrixXd &N_b, VectorXd V8, DualQuaternion* b, DualQuaternion* b_primes)
{
	N_b.resize(8, 8);
	N_b.setZero();

	Vector4d V0 = V8.block(0, 0, 4, 1);
	Vector4d Ve = V8.block(4, 0, 4, 1);
	Vector4d q0 = b_primes->nondual;
	Vector4d qe = b_primes->dual;
	Vector4d Q0 = b->nondual;
	Vector4d Qe = b->dual;
	MatrixXd N_0(4, 4);
	MatrixXd N_e(4, 4);
	MatrixXd N_c(4, 4);

	N_0 = -1.0 / pow(Q0.norm(), 2)*
		(q0*V0.transpose() + V0*q0.transpose() + V0.dot(q0)*(MatrixXd(4, 4).setIdentity() - 3 * q0*q0.transpose()));
	N_e = -1.0 / pow(Q0.norm(), 2)*
		(q0*Ve.transpose() + Ve*q0.transpose() + Ve.dot(q0)*(MatrixXd(4, 4).setIdentity() - 3 * q0*q0.transpose()));
	N_c = -1.0 / pow(Q0.norm(), 2)*
		(
		qe*V0.transpose() + V0*qe.transpose() + V0.dot(qe)*(MatrixXd(4, 4).setIdentity() - 3 * q0*q0.transpose())
		- 3 * V0.dot(q0)*(qe*q0.transpose() + q0*qe.transpose()
		)
		- 2 * Qe.dot(Q0) / pow(Q0.norm(), 2)*N_0);

	N_b.block(0, 0, 4, 4) = N_0;
	N_b.block(4, 0, 4, 4) = N_e + N_c;
	N_b.block(4, 4, 4, 4) = N_0;
}

void DualQuaternionsFramebased::setColumnVectorFromMatrix(VectorXd &V8, int col, MatrixXd &targetMatrix)
{
	int row_length = targetMatrix.rows();
	for (int i = 0; i<row_length; i++)
	{
		targetMatrix.data()[col*row_length + i] = V8[i];
	}
}



void DualQuaternionsFramebased::getColumnVectorFromMatrix(MatrixXd &resourceMatrix, int col, VectorXd &V8)
{
	int row_length = resourceMatrix.rows();
	for (int i = 0; i<row_length; i++)
	{
		V8[i] = resourceMatrix.data()[col*row_length + i];
	}
}

void DualQuaternionsFramebased::Jacobian_framei_point(MatrixXd &Jacobian, DualQuaternionFrame* frame_i, Vector3d* p_bar, DualQuaternion* b_prime, DualQuaternion* b,double w_i)
{
	MatrixXd Q;
	MatrixXd N;
	MatrixXd T_i;
	MatrixXd L_i;
    Jacobian.resize(3, 6);
	partialP_BPrime_Q(Q, p_bar, b_prime);
	partial_Opertor_BPrime_Ns(N, b, b_prime);
	T_i = frame_i->ori_position->productMatrixT();
	Partial_Opertor_L_i(L_i,frame_i);
	Jacobian = w_i*Q*N*T_i*L_i;
}

void DualQuaternionsFramebased::Jacobian_framei_point(MatrixXd &Jacobian, double wi, MatrixXd &Q, MatrixXd &N, MatrixXd &T_i, MatrixXd &L_i)
{
	Jacobian.resize(3, 6);
	Jacobian = wi*Q*N*T_i*L_i;
}

void DualQuaternionsFramebased::Partial_Opertor_L_i(MatrixXd &L_i, DualQuaternionFrame* frame)
{
	L_i.resize(8, 6);
	L_i.setZero();
	MatrixXd L_i0(4, 3);
	L_i0.setZero();
	MatrixXd L_ie(4, 3);
	L_ie.setZero();
	double a0, b0, c0, w0, ae, be, ce, we, tx, ty, tz;
	a0 = frame->cur_position->nondual(0);
	b0 = frame->cur_position->nondual(1);
	c0 = frame->cur_position->nondual(2);
	w0 = frame->cur_position->nondual(3);

	ae = frame->cur_position->dual(0);
	be = frame->cur_position->dual(1);
	ce = frame->cur_position->dual(2);
	we = frame->cur_position->dual(3);

	tx = frame->cur_position->getTransforTranslation().x();
	ty = frame->cur_position->getTransforTranslation().y();
	tz = frame->cur_position->getTransforTranslation().z();

	L_i0(0, 0) = w0;
	L_i0(0, 1) = c0;
	L_i0(0, 2) = -1.0*b0;
	L_i0(1, 0) = -1.0*c0;
	L_i0(1, 1) = w0;
	L_i0(1, 2) = a0;
	L_i0(2, 0) = b0;
	L_i0(2, 1) = -1.0*a0;
	L_i0(2, 2) = w0;
	L_i0(3, 0) = -1.0*a0;
	L_i0(3, 1) = -1.0*b0;
	L_i0(3, 2) = -1.0*c0;

	L_ie(0, 0) = we + c0*tz + b0*ty;
	L_ie(0, 1) = ce - w0*tz - b0*tx;
	L_ie(0, 2) = -1.0*be + w0*ty - c0*tx;
	L_ie(1, 0) = -1.0*ce + w0*tz - a0*ty;
	L_ie(1, 1) = we + c0*tz + a0*tx;
	L_ie(1, 2) = ae - w0*tx - c0*ty;
	L_ie(2, 0) = be - w0*ty - a0*tz;
	L_ie(2, 1) = -1.0*ae + w0*tx - b0*tz;
	L_ie(2, 2) = we + b0*ty + a0*tx;
	L_ie(3, 0) = -1.0*ae - b0*tz + c0*ty;
	L_ie(3, 1) = -1.0*be + a0*tz - c0*tx;
	L_ie(3, 2) = -1.0*ce - a0*ty + b0*tx;

	L_i.setZero();
	L_i.block(0, 0, 4, 3) = L_i0;
	L_i.block(4, 0, 4, 3) = L_ie;
	L_i.block(4, 3, 4, 3) = L_i0;
	L_i *= 0.5;
}

void DualQuaternionsFramebased::transforMatrixToVector(MatrixXd &resourceMatrix, VectorXd &V6)
{
	V6[0] = resourceMatrix.coeff(0, 0);
	V6[1] = resourceMatrix.coeff(1, 1);
	V6[2] = resourceMatrix.coeff(2, 2);
	V6[3] = resourceMatrix.coeff(0, 1);
	V6[4] = resourceMatrix.coeff(1, 2);
	V6[5] = resourceMatrix.coeff(0, 2);
}

void DualQuaternionsFramebased::strain_tensor_E(MatrixXd &F, VectorXd &E_p)
{
	MatrixXd E(3, 3);
	E_p.resize(6);
	E = F.transpose()*F - MatrixXd(3, 3).setIdentity();
	E *= 0.5;
	this->transforMatrixToVector(E, E_p);
}

void DualQuaternionsFramebased::computeDeformationGradientF(MatrixXd &output, MatrixXd &R, MatrixXd &Q, MatrixXd &N, MatrixXd &W)
{
	output = R + Q*N*W;
}

void DualQuaternionsFramebased::Partial_Opertor_b_pbar_W(MatrixXd &W, QuadraticElement &element)
{
	W.resize(8, 3);
	W.setZero();
	for (int i = 0; i<frame_list_.size(); i++)
	{
		W = W + (frame_list_[i]->ori_position->productMatrixT()*
			(*(frame_list_[i]->cur_position)))
			* (element.weight_gradients[i]);
	}
}

/// <summary>
/// Partial_s the opertor_bprime_b_ n.
/// </summary>
/// <param name="N">The N matrix 8X8.</param>
/// <param name="b">The b.</param>
/// <param name="b_primes">The b_primes.</param>
void DualQuaternionsFramebased::partial_Opertor_BPrime_Ns(MatrixXd &b_N, DualQuaternion* b, DualQuaternion* b_primes)
{
	b_N.resize(8, 8);
	b_N.setZero();
	MatrixXd N0(4, 4);
	MatrixXd Ne(4, 4);
	N0 = -1 / b->nondual.norm()*(b_primes->nondual*b_primes->nondual.transpose() - MatrixXd(4, 4).setIdentity());
	Ne = -1 / b->nondual.norm()*(b_primes->nondual*b_primes->dual.transpose() + b_primes->dual*b_primes->nondual.transpose())
		- b->dual.dot(b->nondual) / pow(b->nondual.norm(), 3)
		*(MatrixXd(4, 4).setIdentity() - b_primes->nondual*b_primes->nondual.transpose());
	b_N.block(0, 0, 4, 4) = N0;
	b_N.block(4, 0, 4, 4) = Ne;
	b_N.block(4, 4, 4, 4) = N0;
}

void DualQuaternionsFramebased::partialP_BPrime_Q(MatrixXd &Q, Vector3d* p_bar, DualQuaternion* b_prime)
{
	Q.resize(3, 8);
	Q.setZero();
	double a0, b0, c0, w0, ae, be, ce, we, x, y, z;
	a0 = b_prime->nondual(0);
	b0 = b_prime->nondual(1);
	c0 = b_prime->nondual(2);
	w0 = b_prime->nondual(3);

	ae = b_prime->dual(0);
	be = b_prime->dual(1);
	ce = b_prime->dual(2);
	we = b_prime->dual(3);

	x = p_bar->x();
	y = p_bar->y();
	z = p_bar->z();

	Q(0, 0) = -we + a0*x + b0*y + c0*z;
	Q(0, 1) = ce - b0*x + a0*y + w0*z;
	Q(0, 2) = -be - c0*x - w0*y + a0*z;
	Q(0, 3) = ae + w0*x - c0*y + b0*z;
	Q(0, 4) = w0;
	Q(0, 5) = -c0;
	Q(0, 6) = b0;
	Q(0, 7) = -a0;

	Q(1, 0) = -ce + b0*x - a0*y - w0*z;
	Q(1, 1) = -we + a0*x + b0*y + c0*z;
	Q(1, 2) = ae + w0*x - c0*y + b0*z;
	Q(1, 3) = be + c0*x + w0*y - a0*z;
	Q(1, 4) = c0;
	Q(1, 5) = w0;
	Q(1, 6) = -a0;
	Q(1, 7) = -b0;

	Q(2, 0) = be + c0*x + w0*y - a0*z;
	Q(2, 1) = -ae - w0*x + c0*y - b0*z;
	Q(2, 2) = -we + a0*x + b0*y + c0*z;
	Q(2, 3) = ce - b0*x + a0*y + w0*z;
	Q(2, 4) = -b0;
	Q(2, 5) = a0;
	Q(2, 6) = w0;
	Q(2, 7) = -c0;
	Q *= 2.0;
}

void DualQuaternionsFramebased::frameQuaternionsBlending(QuadraticElement &element, DualQuaternion& b, DualQuaternion& b_prime)
{
	b.nondual.setZero();
	b.dual.setZero();

	for (int i = 0; i < frame_list_.size(); i++)
	{
		double w;
		w = element.weights[i];
		b = b + w*(frame_list_[i]->ori_position->productMatrixT()*(*frame_list_[i]->cur_position));
	}
	b_prime = (b.normlize());
}

void DualQuaternionsFramebased::computeHooke_Stiffness_Matrix(MatrixXd &Hooke_Stiffness_Matrix, double youngs_modulus, double poisson_ratio)
{
	Hooke_Stiffness_Matrix.resize(6, 6);
	Hooke_Stiffness_Matrix.setZero();
	double scalar = youngs_modulus*(1 - poisson_ratio) / (1 + poisson_ratio)*(1 - 2 * poisson_ratio);
	Hooke_Stiffness_Matrix(0, 0) = 1;
	Hooke_Stiffness_Matrix(1, 1) = 1;
	Hooke_Stiffness_Matrix(2, 2) = 1;
	Hooke_Stiffness_Matrix(0, 1) = poisson_ratio / (1 - poisson_ratio);
	Hooke_Stiffness_Matrix(0, 2) = poisson_ratio / (1 - poisson_ratio);
	Hooke_Stiffness_Matrix(1, 0) = poisson_ratio / (1 - poisson_ratio);
	Hooke_Stiffness_Matrix(1, 2) = poisson_ratio / (1 - poisson_ratio);
	Hooke_Stiffness_Matrix(2, 0) = poisson_ratio / (1 - poisson_ratio);
	Hooke_Stiffness_Matrix(2, 1) = poisson_ratio / (1 - poisson_ratio);

	Hooke_Stiffness_Matrix(3, 3) = (1 - 2 * poisson_ratio) / (2 * (1 - poisson_ratio));
	Hooke_Stiffness_Matrix(4, 4) = (1 - 2 * poisson_ratio) / (2 * (1 - poisson_ratio));
	Hooke_Stiffness_Matrix(5, 5) = (1 - 2 * poisson_ratio) / (2 * (1 - poisson_ratio));

	Hooke_Stiffness_Matrix *= scalar;
}
#include "DualQuaternionsFramebased.h"

DualQuaternionFrame::DualQuaternionFrame()
{
	ori_position_.resize(6);
	cur_position_.resize(6);
	dofs_force.resize(6);

	ori_position_.setZero();
	cur_position_.setZero();
	dofs_force.setZero();

	rotationMatrix_.setZero();
	translation_.setZero();

	this->ori_position = new DualQuaternion();
	this->cur_position = new DualQuaternion();
}

DualQuaternionFrame::~DualQuaternionFrame()
{
	delete this->ori_position;
	delete this->cur_position;
}

void DualQuaternionFrame::updateMatrix(double time_step)
{
	Vector3d angular_vel_w;
	angular_vel_w.data()[0] = cur_position_.data()[0];
	angular_vel_w.data()[1] = cur_position_.data()[1];
	angular_vel_w.data()[2] = cur_position_.data()[2];
	Vector3d linear_vel_t;
	linear_vel_t.data()[0] = cur_position_.data()[3];
	linear_vel_t.data()[1] = cur_position_.data()[4];
	linear_vel_t.data()[2] = cur_position_.data()[5];

	Vector3d v = this->cur_position->nondual.block(0, 0, 3, 1);
	double s = this->cur_position->nondual[3];
	Vector4d q0;
	q0[3] = -1.0*angular_vel_w.dot(v);
	v = angular_vel_w.cross(v) + s*(angular_vel_w);
	q0.block(0, 0, 3, 1) = v;
	this->cur_position->nondual += (time_step / 2.0)*q0;
	
	translation_ += (time_step*(linear_vel_t));

	cur_position->dual.setZero();
	cur_position->dual.block(0, 0, 3, 1) = translation_;
	Vector4d temp;
	Vector3d v2 = cur_position->nondual.block(0, 0, 3, 1);
	temp(3) = -1.0*(translation_).dot(v2);
	temp.block(0, 0, 3, 1) = (translation_).cross(v2) + cur_position->nondual(3)*(translation_);
	cur_position->dual = temp / 2.0;
	cur_position->normlized();
}

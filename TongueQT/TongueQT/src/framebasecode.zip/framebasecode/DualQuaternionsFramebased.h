#pragma once
#include "InvertibleQuadraticFrameSimulator.h"
#include "DualQuaternion.h"

class DualQuaternionFrame :public FrameBase
{
public :
	DualQuaternionFrame();
	~DualQuaternionFrame();

	void updateMatrix(double time_step);

	DualQuaternion* ori_position;
	DualQuaternion* cur_position;
	MatrixXd jacobi;
	MatrixXd B_i;
};

class DualQuaternionsFramebased :
	public InvertibleQuadraticFrameSimulator
{
public:
	DualQuaternionsFramebased();
	~DualQuaternionsFramebased();

	virtual void setSimulatorName(const char* simulator_name){};
	virtual const char* getSimulatorName(){ return ""; };

	virtual void init();
	virtual void preCompute();
	virtual void computeMatrix();
	virtual void simulate();
	virtual void updateTriMesh();
	virtual void resetSimulator();
	virtual void paintSimulator(QPainter &painter);
	virtual void drawSimulator(QOpenGLShaderProgram *program);
	virtual void readConfig(std::ifstream &inStream, LoboScene* scene);
	virtual void clear();

	virtual void keyPressEvent(QKeyEvent *key_event);
	virtual void keyReleaseEvent(QKeyEvent *key_event);

	//API
	void computeMatrixByElement(std::vector<QuadraticElement>& elementlist, VectorXd *internalforce = NULL, std::vector<int> *regionnode_indices = NULL, std::vector<double> *cubature_weight = NULL, bool fillstiffnes = true, bool invertible = true, MatrixXd *stiffness = NULL);

protected:
	void computePureBending();
	void simulateIntegrate();
	void computeExternalForce();
	void computeWeight(int type, int readmode);
	void Partial_DOFS_F_k(
		MatrixXd &output,
		double wi,
		QuadraticElement* element,
		DualQuaternion* b,
		DualQuaternion* b_prime,
		DualQuaternionFrame* frame_i,
		VectorXd& R_V8,
		VectorXd &W_i_V8,
		VectorXd &Q_i_V8,
		VectorXd &N_i_V8,
		MatrixXd &Q,
		MatrixXd &N,
		MatrixXd &Ti,
		MatrixXd &W,
		int frame_number
		);

	void Partial_B_i(MatrixXd &output,double wi,
		QuadraticElement* element,
		DualQuaternion* b,
		DualQuaternion* b_prime,
		DualQuaternionFrame* frame_i,
		MatrixXd &Q,
		MatrixXd &N,
		MatrixXd &Ti,
		MatrixXd &W,
		MatrixXd &Li,
		MatrixXd &F_i,
		int frame_number);
	void Jacobian_framei_point(MatrixXd &output, DualQuaternionFrame* frame_i, Vector3d* p_bar, DualQuaternion* b_prime, DualQuaternion* b, double w_i);
	void Jacobian_framei_point(MatrixXd &output, double wi, MatrixXd &Q, MatrixXd &N, MatrixXd &T_i, MatrixXd &L_i);
	void Partial_Opertor_L_i(MatrixXd &output,DualQuaternionFrame* frame);
	void transforMatrixToVector(MatrixXd &resourceMatrix, VectorXd &V6);
	void strain_tensor_E(MatrixXd &F, VectorXd &E);
	inline void computeDeformationGradientF(MatrixXd &output,MatrixXd &R, MatrixXd &Q, MatrixXd &N, MatrixXd &W);
	void Partial_Opertor_b_pbar_W(MatrixXd &W_s, QuadraticElement &element);
	void partial_Opertor_BPrime_Ns(MatrixXd &N,DualQuaternion* b, DualQuaternion* b_primes); // 8*8
	void partialP_BPrime_Q(MatrixXd &Qs,Vector3d* p_bar, DualQuaternion* b_prime);
	void frameQuaternionsBlending(QuadraticElement &element, DualQuaternion& b, DualQuaternion& b_prime);
	void computeHooke_Stiffness_Matrix(MatrixXd &Hooke_matrix,double youngs_modulus,double poisson_ratio);
	void loadFrameBase(const char* filebase);
	void preComputeTriMeshwX();
	void computeJacobiX(MatrixXd &X, Vector3d& p_bar);
	void preComputeElement(std::vector<QuadraticElement>& elementlist);
	void getColumnVectorFromMatrix(MatrixXd &resourceMatrix, int col, VectorXd &V8);
	void setColumnVectorFromMatrix(VectorXd &V8, int col, MatrixXd &targetMatrix);

	void Partial_Opertor_R_b(MatrixXd &output,VectorXd &V8, DualQuaternion* b_prime); //input 8*1 vector; output 3*3;
	void Partial_Opertor_W_q(MatrixXd &output, VectorXd &V8, MatrixXd &W_i); //output 8*8;
	void Partial_Opertor_Q_b(MatrixXd &output,VectorXd &V8, Vector3d* p_bar); //input 8*1 vector; output 3*8;
	void Partial_OPertor_N_b(MatrixXd &output,VectorXd V8, DualQuaternion* b, DualQuaternion* b_primes);

	MatrixXd Hooke_Stiffness_Matrix;
	MatrixXd R_s;
	Vector3d t_s;
	MatrixXd Q_s;
	MatrixXd N_s;
	MatrixXd F_s;
	MatrixXd W_s;
	VectorXd E_s;
	MatrixXd Ti;
	MatrixXd L_i;
	MatrixXd J_si;
	MatrixXd B_si;
	MatrixXd tri_weight;
	VectorXd mesh_position;

	double damp_ratio;

	std::vector<DualQuaternionFrame*> frame_list_;
};


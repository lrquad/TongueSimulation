#include "DualQuaternion.h"


DualQuaternion::DualQuaternion()
{
	init();
}


DualQuaternion::~DualQuaternion()
{
	delete T;
}

void DualQuaternion::init()
{
	T = NULL;
	this->dual.setZero();
	this->nondual.setZero();
	this->nondual(3) = 1;
}

DualQuaternion::DualQuaternion(Vector4d nondualpart, Vector4d dualpart)
{
	init();
	this->dual = dualpart;
	this->nondual = nondualpart;
}

DualQuaternion::DualQuaternion(Vector3d translate)
{
	init();
	dual.block(0, 0, 3, 1) = translate;
}

void DualQuaternion::setPosition(Vector3d &translate, Matrix3d &rotationMatrix)
{
	Quaterniond tempq(rotationMatrix);
	nondual(0) = tempq.x();
	nondual(1) = tempq.y();
	nondual(2) = tempq.z();
	nondual(3) = tempq.w();

	dual.setZero();
	dual.block(0, 0, 3, 1) = translate;
	Vector4d temp;

	Vector3d v = nondual.block(0, 0, 3, 1);
	temp(3) = -1.0*translate.dot(v);
	temp.block(0, 0, 3, 1) = translate.cross(v) + nondual(3)*translate;
	dual = temp / 2.0;

	if (T != NULL)
		this->updateMatrixT();
}

void DualQuaternion::normlized()
{
	VectorXd Q1(8);
	VectorXd Q2(8);
	Q1.block(0, 0, 4, 1) = this->nondual;
	Q1.block(4, 0, 4, 1) = this->dual;
	Q2.block(0, 0, 4, 1).setZero();
	Q2.block(4, 0, 4, 1) = this->nondual;

	double normlized_non_dual_part = this->nondual.norm();
	double normlized_dual_part = nondual.dot(this->dual);

	VectorXd result(8);
	result = 1.0 / normlized_non_dual_part*Q1 - normlized_dual_part /
		(normlized_non_dual_part*normlized_non_dual_part*normlized_non_dual_part)
		*Q2;

	this->dual = result.block(4, 0, 4, 1);
	this->nondual = result.block(0, 0, 4, 1);
}

DualQuaternion DualQuaternion::normlize()
{
	DualQuaternion normlized;
	VectorXd Q1(8);
	VectorXd Q2(8);
	Q1.block(0, 0, 4, 1) = this->nondual;
	Q1.block(4, 0, 4, 1) = this->dual;
	Q2.block(0, 0, 4, 1).setZero();
	Q2.block(4, 0, 4, 1) = this->nondual;



	double normlized_non_dual_part = this->nondual.norm();
	double normlized_dual_part = nondual.dot(this->dual);

	VectorXd result(8);
	result = 1.0 / normlized_non_dual_part*Q1 - normlized_dual_part /
		(normlized_non_dual_part*normlized_non_dual_part*normlized_non_dual_part)
		*Q2;

	normlized.dual = result.block(4, 0, 4, 1);
	normlized.nondual = result.block(0, 0, 4, 1);
	return normlized;
}

Matrix3d DualQuaternion::getTransforRotationMatirx()
{
	Quaterniond rotation(nondual.w(), nondual.x(), nondual.y(), nondual.z());
	return rotation.toRotationMatrix();
}

Vector3d DualQuaternion::getTransforTranslation()
{
	Vector3d translation;
	translation.x() = -1.0*dual(3)*nondual(0) + dual(0)*nondual(3) - dual(1)*nondual(2) + dual(2)*nondual(1);
	translation.y() = -1.0*dual(3)*nondual(1) + dual(0)*nondual(2) + dual(1)*nondual(3) - dual(2)*nondual(0);
	translation.z() = -1.0*dual(3)*nondual(2) - dual(0)*nondual(1) + dual(1)*nondual(0) + dual(2)*nondual(3);
	translation *= 2;
	return translation;
}

MatrixXd DualQuaternion::productMatrixT()
{
	if (T == NULL)
	{
		T = new MatrixXd(8, 8);
		T->setZero();
		T->block(0, 0, 4, 4) = HamiltonOperator(InverseQuaternion(this->nondual));
		T->block(4, 0, 4, 4) = HamiltonOperator(InverseQuaternion(this->dual));
		T->block(4, 4, 4, 4) = HamiltonOperator(InverseQuaternion(this->nondual));
	}
	return *T;
}

void DualQuaternion::updateMatrixT()
{
	T->setZero();
	T->block(0, 0, 4, 4) = HamiltonOperator(InverseQuaternion(this->nondual));
	T->block(4, 0, 4, 4) = HamiltonOperator(InverseQuaternion(this->dual));
	T->block(4, 4, 4, 4) = HamiltonOperator(InverseQuaternion(this->nondual));
}

MatrixXd DualQuaternion::HamiltonOperator(Vector4d& quaternion)
{
	MatrixXd H(4, 4);
	H.setIdentity();
	H *= quaternion(3);
	H(0, 1) = quaternion(2);
	H(0, 2) = -1.0*quaternion(1);
	H(0, 3) = quaternion(0);

	H(1, 0) = -1.0*quaternion(2);
	H(1, 2) = quaternion(0);
	H(1, 3) = quaternion(1);

	H(2, 0) = quaternion(1);
	H(2, 1) = -1.0*quaternion(0);
	H(2, 3) = quaternion(2);

	H(3, 0) = -1.0*quaternion(0);
	H(3, 1) = -1.0*quaternion(1);
	H(3, 2) = -1.0*quaternion(2);

	return H;
}

Vector4d DualQuaternion::InverseQuaternion(Vector4d& quaternion)
{
	Quaterniond temp(quaternion);
	temp = temp.conjugate();
	Vector4d inversedQuaternion(temp.x(), temp.y(), temp.z(), temp.w());
	return inversedQuaternion;
}

DualQuaternion DualQuaternion::operator+(DualQuaternion& dual_right)
{
	DualQuaternion dualquaternion;
	dualquaternion.nondual = nondual + dual_right.nondual;
	dualquaternion.dual = dual + dual_right.dual;
	return dualquaternion;
}

MatrixXd DualQuaternion::operator*(MatrixXd& matrix)
{
	VectorXd dq(8);
	dq.block(0, 0, 4, 1) = nondual;
	dq.block(4, 0, 4, 1) = dual;
	MatrixXd m = dq*matrix;
	return m;
}

DualQuaternion operator*(MatrixXd& matrix, DualQuaternion& dual_right)
{
	VectorXd dq(8);
	dq.block(0, 0, 4, 1) = dual_right.nondual;
	dq.block(4, 0, 4, 1) = dual_right.dual;
	dq = matrix*dq;
	DualQuaternion dualquaternion;
	dualquaternion.nondual = dq.block(0, 0, 4, 1);
	dualquaternion.dual = dq.block(4, 0, 4, 1);
	return dualquaternion;
}

DualQuaternion operator*(double scalar, DualQuaternion& dual_right)
{
	DualQuaternion dualquaternion;
	dualquaternion.nondual = scalar*dual_right.nondual;
	dualquaternion.dual = scalar*dual_right.dual;
	return dualquaternion;
}

std::ostream &operator<<(std::ostream& out, DualQuaternion* dual_right)
{
	out << dual_right->nondual << std::endl;
	out << dual_right->dual;
	return out;
}
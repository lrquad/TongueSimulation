#pragma once
#include "LoboFunctions.h"

class DualQuaternion
{
public:
	DualQuaternion(void);
	~DualQuaternion(void);

	DualQuaternion(Vector4d nondualpart, Vector4d dualpart);
	DualQuaternion(Vector3d translate);


	void init();
	void setPosition(Vector3d &translate, Matrix3d &rotationMatrix);

	Vector4d nondual;
	Vector4d dual;
	MatrixXd *T;

	//DualQuaternion bothDualConjugation(){};//denotes both quaternion and dual conjugation
	DualQuaternion normlize();
	void normlized();//normlized current dualquaternion

	Matrix3d getTransforRotationMatirx();
	Vector3d getTransforTranslation();

	MatrixXd productMatrixT(); // 8*8 matrix T;
	void updateMatrixT();
	MatrixXd HamiltonOperator(Vector4d& quaternion); // 4*4 matrix H^-1;

	void transformVector(Vector3d node);
	DualQuaternion operator+(DualQuaternion& dual_right);
	MatrixXd operator*(MatrixXd& matrix); //8*3;
	friend std::ostream &operator<<(std::ostream& out, DualQuaternion* dual_right);
	friend DualQuaternion operator*(MatrixXd& matrix, DualQuaternion& dual_right);
	friend DualQuaternion operator*(double scalar, DualQuaternion& dual_right);

private:
	Vector4d InverseQuaternion(Vector4d& quaternion);
};


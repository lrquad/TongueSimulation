#include "WeightFunctionLaplacian.h"
#include <fstream>

typedef Eigen::Triplet<double> EIGEN_TRI;

WeightFunctionLaplacian::WeightFunctionLaplacian(LoboVolumetricMesh* volumetricMesh, std::vector<int> seed_index, SparseMatrix<double>* L) :WeightFunction(volumetricMesh, seed_index)
{
	this->Laplacianmatrix = L;
}


WeightFunctionLaplacian::~WeightFunctionLaplacian()
{

}

void WeightFunctionLaplacian::computeWeight()
{
	SparseMatrix<double> A(numVertices + numFrame, numVertices);
	for (int i = 0; i < numFrame; i++)
	{
		std::vector<Triplet<double>> sparseA;
		for (int j = 0; j < Laplacianmatrix->outerSize(); ++j)
			for (SparseMatrix<double>::InnerIterator it(*Laplacianmatrix, j); it; ++it)
			{
				sparseA.push_back(EIGEN_TRI(it.row(), it.col(), it.value()));
			}

		VectorXd B(numVertices + numFrame);
		B.setZero();
		B.data()[numVertices + i] = 1;
		for (int j = 0; j < numFrame; j++)
		{
			sparseA.push_back(EIGEN_TRI(j+numVertices,seed_index[j],1));
		}

		//Ax = B;
		A.setFromTriplets(sparseA.begin(), sparseA.end());
		SparseMatrix<double> K = A.transpose()*A;
		MatrixXd d = A.transpose()*B;

#ifdef EIGEN_USE_MKL_ALL
		PardisoLDLT<SparseMatrix<double>> LDLT(K);
#else 
		SimplicialLDLT<SparseMatrix<double>> LDLT(K);
#endif
		VectorXd result = LDLT.solve(d);

		for (int j = 0; j < numVertices; j++)
		{
			weights[i][j] = result.data()[j];
		}

	}
}